'use client';
import { useState, useEffect } from 'react';
import { generateLevels, Level } from './components/gameData';
import FindClick from './components/FindClick';
import FollowHighlight from './components/FollowHighlight';
import ClickOrder from './components/ClickOrder';
import ProgressDots from './components/ProgressDots';

type Screen = 'home' | 'game' | 'end';

const LEVEL_COLORS = [
  { bg: '#E3EAFF', accent: '#6C8EFF', label: 'Level 1' },
  { bg: '#FFF2CE', accent: '#FFD166', label: 'Level 2' },
  { bg: '#D7F5E8', accent: '#8EE3C3', label: 'Level 3' },
];

const MODE_LABELS: Record<string, string> = {
  'find-click': 'Find & Click',
  'follow-highlight': 'Follow Glow',
  'click-order': 'Click in Order',
};

export default function Home() {
  const [screen, setScreen] = useState<Screen>('home');
  const [levels, setLevels] = useState<Level[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [transitionKey, setTransitionKey] = useState(0);

  const start = () => {
    const generated = generateLevels();
    setLevels(generated);
    setCurrentIdx(0);
    setScreen('game');
    setTransitionKey(k => k + 1);
  };

  const handleCorrect = () => {
    const next = currentIdx + 1;
    if (next >= levels.length) {
      setScreen('end');
    } else {
      setCurrentIdx(next);
      setTransitionKey(k => k + 1);
    }
  };

  const currentLevel = levels[currentIdx];

  // Level badge: 1-3 based on levelNum
  const levelBadgeColor = currentLevel
    ? LEVEL_COLORS[currentLevel.levelNum - 1]
    : LEVEL_COLORS[0];

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      background: '#E9EDF5',
      padding: '24px 16px',
    }}>

      {/* ===== HOME SCREEN ===== */}
      {screen === 'home' && (
        <div style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 40,
          animation: 'fadeIn 400ms ease forwards',
        }}>
          {/* Logo area */}
          <div style={{ textAlign: 'center' }}>
            <div style={{
              fontSize: 64,
              marginBottom: 8,
              filter: 'drop-shadow(0 4px 8px rgba(31,42,68,0.12))',
            }}>💻</div>
            <h1 style={{
              fontSize: 42,
              fontWeight: 900,
              color: '#1F2A44',
              lineHeight: 1.1,
              letterSpacing: '-0.02em',
            }}>
              Laptop Skills
            </h1>
            <p style={{
              fontSize: 22,
              fontWeight: 800,
              color: '#6C8EFF',
              marginTop: 6,
            }}>
              for Kids
            </p>
          </div>

          {/* Mode preview cards */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12, width: '100%', maxWidth: 360 }}>
            {[
              { icon: '🎯', text: 'Click the right letter', color: '#E3EAFF', accent: '#6C8EFF' },
              { icon: '✨', text: 'Find the glowing letter', color: '#FFF2CE', accent: '#C8942A' },
              { icon: '🔤', text: 'Spell a word in order', color: '#D7F5E8', accent: '#2E9C75' },
            ].map((item, i) => (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', gap: 16,
                background: item.color,
                borderRadius: 18,
                padding: '14px 20px',
                boxShadow: '0 2px 0 rgba(31,42,68,0.06)',
              }}>
                <span style={{ fontSize: 28 }}>{item.icon}</span>
                <span style={{ fontSize: 17, fontWeight: 800, color: item.accent }}>{item.text}</span>
              </div>
            ))}
          </div>

          <button
            onClick={start}
            style={{
              background: '#6C8EFF',
              color: 'white',
              fontSize: 26,
              fontWeight: 900,
              fontFamily: 'inherit',
              border: 'none',
              borderRadius: 999,
              padding: '20px 60px',
              cursor: 'pointer',
              boxShadow: '0 6px 0 #3F5FE2, 0 10px 28px rgba(108,142,255,0.35)',
              transition: 'transform 100ms ease, box-shadow 100ms ease',
              letterSpacing: '-0.01em',
            }}
            onMouseEnter={e => {
              (e.target as HTMLElement).style.transform = 'translateY(-2px)';
              (e.target as HTMLElement).style.boxShadow = '0 8px 0 #3F5FE2, 0 14px 32px rgba(108,142,255,0.4)';
            }}
            onMouseLeave={e => {
              (e.target as HTMLElement).style.transform = '';
              (e.target as HTMLElement).style.boxShadow = '0 6px 0 #3F5FE2, 0 10px 28px rgba(108,142,255,0.35)';
            }}
            onMouseDown={e => {
              (e.target as HTMLElement).style.transform = 'translateY(3px)';
              (e.target as HTMLElement).style.boxShadow = '0 3px 0 #3F5FE2';
            }}
            onMouseUp={e => {
              (e.target as HTMLElement).style.transform = '';
              (e.target as HTMLElement).style.boxShadow = '0 6px 0 #3F5FE2, 0 10px 28px rgba(108,142,255,0.35)';
            }}
          >
            Start!
          </button>
        </div>
      )}

      {/* ===== GAME SCREEN ===== */}
      {screen === 'game' && currentLevel && (
        <div
          key={transitionKey}
          style={{
            display: 'flex', flexDirection: 'column', alignItems: 'center',
            width: '100%', maxWidth: 800, gap: 0,
            animation: 'fadeIn 280ms ease forwards',
          }}
        >
          {/* Top bar: level badge + mode */}
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            width: '100%', marginBottom: 28,
          }}>
            <div style={{
              background: levelBadgeColor.bg,
              color: levelBadgeColor.accent,
              fontSize: 14, fontWeight: 900,
              padding: '6px 16px', borderRadius: 999,
              boxShadow: '0 2px 0 rgba(31,42,68,0.06)',
              letterSpacing: '0.04em',
              textTransform: 'uppercase',
            }}>
              {levelBadgeColor.label}
            </div>
            <div style={{
              fontSize: 14, fontWeight: 800, color: 'rgba(31,42,68,0.4)',
            }}>
              {MODE_LABELS[currentLevel.mode]}
            </div>
          </div>

          {/* Instruction */}
          <div style={{
            fontSize: 44,
            fontWeight: 900,
            color: '#1F2A44',
            textAlign: 'center',
            letterSpacing: '-0.02em',
            lineHeight: 1.1,
            marginBottom: 40,
          }}>
            {currentLevel.instruction}
          </div>

          {/* Game area */}
          <div style={{ width: '100%', minHeight: 280, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            {currentLevel.mode === 'find-click' && (
              <FindClick
                target={currentLevel.word}
                instruction={currentLevel.instruction}
                onCorrect={handleCorrect}
              />
            )}
            {currentLevel.mode === 'follow-highlight' && (
              <FollowHighlight
                target={currentLevel.word}
                onCorrect={handleCorrect}
              />
            )}
            {currentLevel.mode === 'click-order' && (
              <ClickOrder
                word={currentLevel.word}
                onCorrect={handleCorrect}
              />
            )}
          </div>

          {/* Progress */}
          <div style={{ marginTop: 32 }}>
            <ProgressDots total={levels.length} current={currentIdx} />
          </div>
        </div>
      )}

      {/* ===== END SCREEN ===== */}
      {screen === 'end' && (
        <div style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 36,
          animation: 'bounceIn 500ms ease forwards',
        }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 80, marginBottom: 12 }}>🌟</div>
            <h2 style={{
              fontSize: 48, fontWeight: 900, color: '#1F2A44',
              letterSpacing: '-0.02em', lineHeight: 1.1,
            }}>
              Well done!
            </h2>
            <p style={{
              fontSize: 20, fontWeight: 800, color: '#30C285', marginTop: 10,
            }}>
              You finished all 9 tasks!
            </p>
          </div>

          <div style={{
            display: 'flex', gap: 16, flexWrap: 'wrap', justifyContent: 'center',
          }}>
            {['🎯 Click', '✨ Glow', '🔤 Spell'].map((label, i) => (
              <div key={i} style={{
                background: LEVEL_COLORS[i].bg,
                color: LEVEL_COLORS[i].accent,
                fontSize: 17, fontWeight: 900,
                padding: '10px 22px', borderRadius: 999,
                boxShadow: '0 3px 0 rgba(31,42,68,0.08)',
              }}>
                {label} ✓
              </div>
            ))}
          </div>

          <button
            onClick={start}
            style={{
              background: '#FFD166',
              color: '#7a4a00',
              fontSize: 24,
              fontWeight: 900,
              fontFamily: 'inherit',
              border: 'none',
              borderRadius: 999,
              padding: '18px 52px',
              cursor: 'pointer',
              boxShadow: '0 6px 0 #C8942A',
              transition: 'transform 100ms ease',
              letterSpacing: '-0.01em',
            }}
            onMouseEnter={e => { (e.target as HTMLElement).style.transform = 'translateY(-2px)'; }}
            onMouseLeave={e => { (e.target as HTMLElement).style.transform = ''; }}
            onMouseDown={e => { (e.target as HTMLElement).style.transform = 'translateY(3px)'; }}
            onMouseUp={e => { (e.target as HTMLElement).style.transform = ''; }}
          >
            Play again!
          </button>
        </div>
      )}
    </div>
  );
}
