'use client';

interface ProgressDotsProps {
  total: number;
  current: number; // 0-indexed, current task
}

export default function ProgressDots({ total, current }: ProgressDotsProps) {
  const remaining = total - current;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
      <div style={{ display: 'flex', gap: 10 }}>
        {Array.from({ length: total }).map((_, i) => (
          <div
            key={i}
            style={{
              width: i === current ? 32 : 14,
              height: 14,
              borderRadius: 999,
              background: i < current ? '#30C285' : i === current ? '#6C8EFF' : 'rgba(31,42,68,0.15)',
              transition: 'all 250ms ease',
            }}
          />
        ))}
      </div>
      <span style={{
        fontSize: 15,
        fontWeight: 800,
        color: 'rgba(31,42,68,0.45)',
        letterSpacing: '0.02em',
      }}>
        {remaining === 0 ? 'All done!' : `${remaining} task${remaining !== 1 ? 's' : ''} remaining`}
      </span>
    </div>
  );
}
