'use client';
import { useState, useEffect, useCallback } from 'react';
import LetterTile from './LetterTile';
import { TILE_COLORS, randomLetters } from './gameData';

interface FollowHighlightProps {
  target: string;
  onCorrect: () => void;
}

interface Tile {
  letter: string;
  colorIdx: number;
  key: string;
}

function shuffle<T>(arr: T[]): T[] {
  return [...arr].sort(() => 0.5 - Math.random());
}

export default function FollowHighlight({ target, onCorrect }: FollowHighlightProps) {
  const [tiles, setTiles] = useState<Tile[]>([]);
  const [clickedIdx, setClickedIdx] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<'idle' | 'correct' | 'wrong'>('idle');
  const [done, setDone] = useState(false);

  const buildTiles = useCallback(() => {
    const distractors = randomLetters([target], 5);
    const all = shuffle([target, ...distractors]);
    return all.map((l, i) => ({
      letter: l,
      colorIdx: i % TILE_COLORS.length,
      key: `${l}-${i}`,
    }));
  }, [target]);

  useEffect(() => {
    setTiles(buildTiles());
    setClickedIdx(null);
    setFeedback('idle');
    setDone(false);
  }, [target, buildTiles]);

  const highlightIdx = tiles.findIndex(t => t.letter === target);

  const handleClick = (idx: number) => {
    if (done) return;
    setClickedIdx(idx);
    if (tiles[idx].letter === target) {
      setFeedback('correct');
      setDone(true);
      setTimeout(onCorrect, 900);
    } else {
      setFeedback('wrong');
      setTimeout(() => {
        setClickedIdx(null);
        setFeedback('idle');
      }, 600);
    }
  };

  const getTileState = (idx: number) => {
    if (clickedIdx === idx && feedback === 'correct') return 'correct';
    if (clickedIdx === idx && feedback === 'wrong') return 'wrong';
    if (idx === highlightIdx) return 'highlighted';
    return 'dimmed';
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 0, width: '100%' }}>
      <div
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          gap: 28,
          justifyContent: 'center',
          alignItems: 'center',
          padding: '16px 0',
          maxWidth: 700,
        }}
      >
        {tiles.map((tile, idx) => (
          <LetterTile
            key={tile.key}
            letter={tile.letter}
            bgColor={TILE_COLORS[tile.colorIdx].bg}
            fgColor={TILE_COLORS[tile.colorIdx].fg}
            onClick={() => handleClick(idx)}
            state={getTileState(idx)}
          />
        ))}
      </div>
      <div style={{ height: 52, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        {feedback === 'correct' && (
          <span style={{ fontSize: 28, fontWeight: 900, color: '#30C285', animation: 'bounceIn 300ms ease forwards' }}>
            Nice! ✓
          </span>
        )}
        {feedback === 'wrong' && (
          <span style={{ fontSize: 24, fontWeight: 800, color: '#F07171' }}>Try again</span>
        )}
      </div>
    </div>
  );
}
