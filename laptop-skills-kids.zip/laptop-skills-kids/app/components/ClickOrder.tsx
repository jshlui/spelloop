'use client';
import { useState, useEffect, useCallback } from 'react';
import LetterTile from './LetterTile';
import { TILE_COLORS } from './gameData';

interface ClickOrderProps {
  word: string;
  onCorrect: () => void;
}

interface Tile {
  letter: string;
  colorIdx: number;
  state: 'idle' | 'done' | 'wrong';
  key: string;
}

// Assign stable positions, shuffled
function shuffle<T>(arr: T[]): T[] {
  return [...arr].sort(() => 0.5 - Math.random());
}

export default function ClickOrder({ word, onCorrect }: ClickOrderProps) {
  const [tiles, setTiles] = useState<Tile[]>([]);
  const [progress, setProgress] = useState(0); // how many letters clicked correctly so far
  const [feedback, setFeedback] = useState<'idle' | 'correct' | 'wrong'>('idle');
  const [wrongIdx, setWrongIdx] = useState<number | null>(null);

  const buildTiles = useCallback(() => {
    const letters = word.split('');
    const shuffledIndices = shuffle(letters.map((_, i) => i));
    return shuffledIndices.map((origIdx, displayIdx) => ({
      letter: letters[origIdx],
      colorIdx: (origIdx + displayIdx) % TILE_COLORS.length,
      state: 'idle' as const,
      key: `${letters[origIdx]}-${origIdx}`,
    }));
  }, [word]);

  useEffect(() => {
    setTiles(buildTiles());
    setProgress(0);
    setFeedback('idle');
    setWrongIdx(null);
  }, [word, buildTiles]);

  const handleClick = (tileIdx: number) => {
    const tile = tiles[tileIdx];
    if (tile.state === 'done') return;
    const expected = word[progress];
    if (tile.letter === expected) {
      const newProgress = progress + 1;
      setTiles(prev => prev.map((t, i) => i === tileIdx ? { ...t, state: 'done' } : t));
      setProgress(newProgress);
      setFeedback('correct');
      if (newProgress === word.length) {
        setTimeout(onCorrect, 1000);
      } else {
        setTimeout(() => setFeedback('idle'), 400);
      }
    } else {
      setWrongIdx(tileIdx);
      setFeedback('wrong');
      setTiles(prev => prev.map((t, i) => i === tileIdx ? { ...t, state: 'wrong' } : t));
      setTimeout(() => {
        setTiles(prev => prev.map((t, i) => i === tileIdx ? { ...t, state: 'idle' } : t));
        setFeedback('idle');
        setWrongIdx(null);
      }, 600);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 24, width: '100%' }}>
      {/* Order slots — show progress */}
      <div style={{ display: 'flex', gap: 14, justifyContent: 'center' }}>
        {word.split('').map((letter, i) => (
          <div
            key={i}
            style={{
              width: 72,
              height: 80,
              borderRadius: 14,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 44,
              fontWeight: 900,
              background: i < progress ? '#30C285' : 'rgba(31,42,68,0.08)',
              color: i < progress ? 'white' : 'rgba(31,42,68,0.22)',
              border: i < progress ? 'none' : '3px dashed rgba(31,42,68,0.18)',
              transition: 'background 200ms ease, color 200ms ease',
              boxShadow: i < progress ? '0 4px 0 rgba(15,90,50,0.2)' : 'none',
            }}
          >
            {i < progress ? letter : '?'}
          </div>
        ))}
      </div>

      {/* Letter tiles to click */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 28, justifyContent: 'center', maxWidth: 700 }}>
        {tiles.map((tile, idx) => (
          <LetterTile
            key={tile.key}
            letter={tile.letter}
            bgColor={TILE_COLORS[tile.colorIdx].bg}
            fgColor={TILE_COLORS[tile.colorIdx].fg}
            onClick={() => handleClick(idx)}
            state={tile.state}
          />
        ))}
      </div>

      <div style={{ height: 52, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        {feedback === 'correct' && progress < word.length && (
          <span style={{ fontSize: 24, fontWeight: 900, color: '#30C285' }}>Good!</span>
        )}
        {feedback === 'correct' && progress === word.length && (
          <span style={{ fontSize: 28, fontWeight: 900, color: '#30C285', animation: 'bounceIn 300ms ease forwards' }}>
            Nice! ✓
          </span>
        )}
        {feedback === 'wrong' && (
          <span style={{ fontSize: 24, fontWeight: 800, color: '#F07171' }}>Try again</span>
        )}
      </div>
    </div>
  );
}
