'use client';
import { useState, useRef } from 'react';

interface LetterTileProps {
  letter: string;
  bgColor: string;
  fgColor: string;
  onClick: () => void;
  state?: 'idle' | 'correct' | 'wrong' | 'dimmed' | 'highlighted' | 'done';
  size?: 'lg' | 'xl';
}

export default function LetterTile({ letter, bgColor, fgColor, onClick, state = 'idle', size = 'lg' }: LetterTileProps) {
  const [hovered, setHovered] = useState(false);
  const tileRef = useRef<HTMLButtonElement>(null);

  const isXl = size === 'xl';
  const w = isXl ? 120 : 96;
  const h = isXl ? 136 : 112;
  const fs = isXl ? 72 : 56;

  let bg = bgColor;
  let fg = fgColor;
  let opacity = 1;
  let boxShadow = '0 5px 0 rgba(31,42,68,0.15), 0 2px 12px rgba(31,42,68,0.08)';
  let outline = 'none';
  let animation = '';

  if (state === 'correct' || state === 'done') {
    bg = '#30C285';
    fg = '#ffffff';
    boxShadow = '0 5px 0 rgba(15,90,50,0.25)';
    animation = 'pop 350ms ease forwards';
  } else if (state === 'wrong') {
    bg = '#F07171';
    fg = '#ffffff';
    animation = 'shake 300ms ease forwards';
  } else if (state === 'dimmed') {
    opacity = 0.25;
  } else if (state === 'highlighted') {
    outline = '4px solid #FFD166';
    boxShadow = '0 5px 0 rgba(31,42,68,0.15), 0 0 0 8px rgba(255,209,102,0.35)';
  }

  if (hovered && state === 'idle') {
    boxShadow = '0 8px 0 rgba(31,42,68,0.18), 0 4px 20px rgba(31,42,68,0.15)';
  }

  return (
    <button
      ref={tileRef}
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        width: w,
        height: h,
        borderRadius: 18,
        background: bg,
        color: fg,
        fontSize: fs,
        fontWeight: 900,
        fontFamily: 'inherit',
        border: 'none',
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        boxShadow,
        outline,
        opacity,
        transform: hovered && state === 'idle' ? 'translateY(-4px) scale(1.06)' : 'none',
        transition: 'transform 120ms ease, box-shadow 120ms ease, opacity 200ms ease',
        animation,
        userSelect: 'none',
        position: 'relative',
        lineHeight: 1,
      }}
    >
      {letter}
    </button>
  );
}
