// Game data: words, levels, tile colors

export const WORDS = [
  'CAT', 'DOG', 'SUN', 'FISH', 'BALL',
  'TREE', 'HOUSE', 'APPLE', 'TRAIN', 'BOOK',
];

export const TILE_COLORS = [
  { bg: '#FFD166', fg: '#1F2A44' },  // yellow
  { bg: '#6C8EFF', fg: '#ffffff' },  // blue
  { bg: '#FF9ECD', fg: '#7a1a5a' },  // pink
  { bg: '#8EE3C3', fg: '#0f5c42' },  // mint
  { bg: '#FFA07A', fg: '#7a2a0a' },  // coral
  { bg: '#C7B4FF', fg: '#3a1a8a' },  // lilac
];

export type GameMode = 'find-click' | 'follow-highlight' | 'click-order';

export interface Level {
  mode: GameMode;
  word: string;
  instruction: string;
  levelNum: 1 | 2 | 3;
}

// Build 9 tasks: 3 per mode, cycling through words
function buildLevels(): Level[] {
  const levels: Level[] = [];
  const words = [...WORDS].sort(() => 0.5 - Math.random()).slice(0, 9);

  // Level 1: Find & Click (single letter) — 3 tasks
  for (let i = 0; i < 3; i++) {
    const letter = words[i][Math.floor(Math.random() * words[i].length)];
    levels.push({
      mode: 'find-click',
      word: letter,
      instruction: `Click  ${letter}`,
      levelNum: 1,
    });
  }
  // Level 2: Follow Highlight — 3 tasks
  for (let i = 3; i < 6; i++) {
    const letter = words[i][Math.floor(Math.random() * words[i].length)];
    levels.push({
      mode: 'follow-highlight',
      word: letter,
      instruction: 'Click the glow',
      levelNum: 2,
    });
  }
  // Level 3: Click in Order — 3 tasks
  for (let i = 6; i < 9; i++) {
    levels.push({
      mode: 'click-order',
      word: words[i],
      instruction: `Spell  ${words[i]}`,
      levelNum: 3,
    });
  }
  return levels;
}

export function generateLevels(): Level[] {
  return buildLevels();
}

// Random letters to use as distractors
export function randomLetters(exclude: string[], count: number): string[] {
  const pool = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').filter(l => !exclude.includes(l));
  const shuffled = pool.sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
}
