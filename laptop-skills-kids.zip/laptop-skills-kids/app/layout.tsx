import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Laptop Skills Kids",
  description: "Learn to use a computer — for kids aged 4–10",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
